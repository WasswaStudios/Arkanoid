# Arkanoid
A simple Unity game with unity 5.5 2017.3.0f3

#### Play with Arkanoid

Use key `a` and `d` to move left and right.

#### Todo List

1. [ ] Add AI Player
2. [ ] Speed up for the ball


#### How to make this game:

https://noobtuts.com/unity/arkanoid
